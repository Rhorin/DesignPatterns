public class PlainPizza implements Pizza {

	
	public String getDescription() {
		return "Thin Dough";
	}

	
	public double getCost() {
		return 4.00;
	}
	
	

}
