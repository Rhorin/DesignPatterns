public class Simulator {

	public static void main(String[] args) {
		King max = new King();
		max.fight();
		
		Queen aria = new Queen();
		aria.fight();
		
		Knight leo = new Knight();
		leo.fight();
		
		Troll bloo = new Troll();
		bloo.fight();
	}
}
