
public class SwordBehavior implements WeaponBehavior {
	
	public void useWeapon() {
		System.out.println("The King swings his sword!");
	}
}
