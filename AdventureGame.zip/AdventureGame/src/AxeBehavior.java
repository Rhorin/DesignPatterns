
public class AxeBehavior implements WeaponBehavior {
	public void useWeapon() {
		System.out.println("The Troll violently swings its axe");
	}
}
