public class Queen extends Character{

	public Queen () {
		weapon = new KnifeBehavior();
	}
}
