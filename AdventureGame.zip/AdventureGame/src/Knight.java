public class Knight extends Character {

	public Knight() {
		weapon = new BowAndArrowBehavior();
	}
}
