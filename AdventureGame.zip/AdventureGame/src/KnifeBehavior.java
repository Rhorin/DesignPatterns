
public class KnifeBehavior implements WeaponBehavior {
	public void useWeapon() {
		System.out.println("The Queen lunges forward with a knife");
	}
}
