
public class BowAndArrowBehavior implements WeaponBehavior {
	public void useWeapon() {
		System.out.println("The Knight draws an arrow and fires");
	}
}
